class Config {
  static const String baseUrl = "https://drivesafe-backend.azurewebsites.net";
}